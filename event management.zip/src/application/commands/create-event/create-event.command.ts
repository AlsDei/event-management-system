import { Test, TestingModule } from '@nestjs/testing';
import { CreateEventService } from './create-event.service';

describe('CreateEventService', () => {
  let service: CreateEventService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [CreateEventService],
    }).compile();

    service = module.get<CreateEventService>(CreateEventService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
